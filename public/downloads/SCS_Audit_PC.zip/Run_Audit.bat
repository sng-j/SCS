@echo off
setlocal
set "SCS_SAVE_DIR=%~dp0"
copy /Y "%~dp0SCS_PC.dat" "%TEMP%\scs_in.dat" >nul
copy /Y "%~dp0extract.ps1" "%TEMP%\scs_ex.ps1" >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\scs_ex.ps1"
powershell.exe -NoProfile -Sta -ExecutionPolicy Bypass -File "%TEMP%\scs_run.ps1"
del "%TEMP%\scs_in.dat" >nul 2>&1
del "%TEMP%\scs_ex.ps1" >nul 2>&1
del "%TEMP%\scs_run.ps1" >nul 2>&1
endlocal
